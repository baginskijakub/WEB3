# typescript-eslint-prettier-boilerplate

Simple boilerplate with TypeScript, Prettier, and ESLint configured.

## Getting Started
Install node modules: `npm install`

Run the code with auto restart: `npm run dev`
