import { UserDAO } from './user'
import { LobbyDAO } from './lobby'

export const DataAccess = {
  UserDAO,
  LobbyDAO,
}