<script setup lang="ts"></script>

<template>
  <div class="w-56 h-80 border-[12px] shadow-lg border-white rounded-lg relative bg-black">
    <span
      class="h-40 w-60 border-8 border-white bg-red-700 rounded-[50%] -rotate-45 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center"
    >
      <span class="text-6xl font-black text-yellow-400 [text-shadow:_0_5px_0_rgb(0_0_0_/_100%)]"> UNO </span>
    </span>
  </div>
</template>

<style scoped></style>
