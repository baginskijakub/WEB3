<script setup lang="ts"></script>

<template>
  <div class="bg-slate-100 h-svh overflow-hidden relative">
    <NuxtPage />
  </div>
</template>
