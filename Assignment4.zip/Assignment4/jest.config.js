module.exports = {
  coverageProvider: 'v8',
  testPathIgnorePatterns: [
    '\\\\node_modules\\\\',
    '\\\\dist\\\\'
  ]
}
